/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 745);
/******/ })
/************************************************************************/
/******/ ({

/***/ 10:
/***/ (function(module, exports) {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

module.exports = _asyncToGenerator;

/***/ }),

/***/ 12:
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ 13:
/***/ (function(module, exports) {

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ 16:
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ 180:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.attachPdfIframeToggler = exports.resizeIframe = exports.changeIframeVisibility = exports.removeIframe = exports.shrinkIframe = exports.enlargeIframe = exports.isIframeSmall = exports.isIframeInjected = exports.isIframeVisible = exports.setBoxActive = exports.setSelectionMode = exports.showIframe = exports.mockShowIframe = exports.focusIframe = exports.updateHeight = exports.hideIframe = void 0;

var getIframeElement = function getIframeElement() {
  return document.getElementById('paperpile-iframe');
};

var hideIframe = function hideIframe() {
  var iframe = getIframeElement();

  if (iframe) {
    iframe.style.display = 'none';
    iframe.classList.remove('selection-mode');
  }
};

exports.hideIframe = hideIframe;

var updateHeight = function updateHeight(_ref) {
  var height = _ref.height;
  var iframe = getIframeElement();

  if (iframe) {
    iframe.style.height = "".concat(height + 6, "px");
  }
};

exports.updateHeight = updateHeight;

var focusIframe = function focusIframe() {
  var iframe = getIframeElement();

  if (iframe) {
    iframe.focus();
  }
};

exports.focusIframe = focusIframe;

var mockShowIframe = function mockShowIframe() {
  var iframe = getIframeElement();

  if (iframe) {
    iframe.style.opacity = '0';
    iframe.style.display = 'block';
  }
};

exports.mockShowIframe = mockShowIframe;

var showIframe = function showIframe(params) {
  var iframe = getIframeElement();

  if (iframe) {
    iframe.style.opacity = '1';
    iframe.style.display = 'block';

    if (params) {
      if (params.selectionMode) {
        iframe.classList.add('selection-mode');
      }
    }
  }
};

exports.showIframe = showIframe;

var setSelectionMode = function setSelectionMode() {
  var iframe = getIframeElement();

  if (iframe) {
    iframe.classList.add('selection-mode');
  }
};

exports.setSelectionMode = setSelectionMode;

var setBoxActive = function setBoxActive(_ref2) {
  var state = _ref2.state;
  var iframe = getIframeElement();

  if (iframe) {
    if (state) {
      iframe.classList.add('textbox-active');
    } else {
      iframe.classList.remove('textbox-active');
    }
  }
};

exports.setBoxActive = setBoxActive;

var isIframeVisible = function isIframeVisible() {
  var iframe = getIframeElement();
  if (!iframe) return null;
  return iframe ? iframe.style.display === 'block' : false;
};

exports.isIframeVisible = isIframeVisible;

var isIframeInjected = function isIframeInjected() {
  return getIframeElement() !== null;
};

exports.isIframeInjected = isIframeInjected;

var isIframeSmall = function isIframeSmall() {
  var iframe = getIframeElement();
  if (!iframe) return false;
  return iframe.offsetWidth === 424;
};

exports.isIframeSmall = isIframeSmall;

var enlargeIframe = function enlargeIframe() {
  var iframe = getIframeElement();
  if (!iframe) return false;
  iframe.style.width = "".concat(document.documentElement.clientWidth.toString(), "px");
  iframe.style.height = "".concat(document.documentElement.clientHeight.toString(), "px");
  return true;
};

exports.enlargeIframe = enlargeIframe;

var shrinkIframe = function shrinkIframe() {
  var iframe = getIframeElement();
  if (!iframe) return false;
  iframe.style.width = '424px';
  iframe.style.height = '302px';
  return true;
};

exports.shrinkIframe = shrinkIframe;

var removeIframe = function removeIframe() {
  var iframe = document.getElementById('paperpile-iframe');
  if (!iframe) return false;
  iframe.remove();
  return true;
};

exports.removeIframe = removeIframe;

var changeIframeVisibility = function changeIframeVisibility() {
  if (isIframeVisible()) {
    hideIframe();
  } else {
    showIframe();
  }
};

exports.changeIframeVisibility = changeIframeVisibility;

var resizeIframe = function resizeIframe() {
  if (isIframeSmall()) {
    enlargeIframe();
  } else {
    shrinkIframe();
  }
};

exports.resizeIframe = resizeIframe;

var attachPdfIframeToggler = function attachPdfIframeToggler() {
  var lastActiveElement;
  focusIframe();
  setInterval(function () {
    var currentActiveElement = document.activeElement;

    if (lastActiveElement === currentActiveElement) {
      return null;
    }

    if (lastActiveElement && currentActiveElement && currentActiveElement.tagName === 'EMBED' && isIframeVisible()) {
      // hideIframe();
      focusIframe();
    } else if (lastActiveElement !== currentActiveElement) {
      if (document.activeElement) {
        document.activeElement.blur();
      }
    }

    lastActiveElement = currentActiveElement;
    return null;
  }, 100);
};

exports.attachPdfIframeToggler = attachPdfIframeToggler;

/***/ }),

/***/ 2:
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ 20:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(53);


/***/ }),

/***/ 21:
/***/ (function(module, exports) {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

module.exports = _asyncToGenerator;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ 230:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(5);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Remote = _interopRequireDefault(__webpack_require__(81));

var _iframeHelpers = __webpack_require__(180);

// We store Remote as global as other `cs` scripts will hook to it on load
if (!self.Remote) {
  self.Remote = new _Remote.default({
    origin: 'cs',
    logger: self.Logger
  });
}

self.Remote.addActions({
  'popup.iframe-helpers.changeIframeVisibility': _iframeHelpers.changeIframeVisibility,
  'popup.iframe-helpers.showIframe': _iframeHelpers.showIframe,
  'popup.iframe-helpers.mockShowIframe': _iframeHelpers.mockShowIframe,
  'popup.iframe-helpers.hideIframe': _iframeHelpers.hideIframe,
  'popup.iframe-helpers.resizeIframe': _iframeHelpers.resizeIframe,
  'popup.iframe-helpers.removeIframe': _iframeHelpers.removeIframe,
  'popup.iframe-helpers.updateHeight': _iframeHelpers.updateHeight,
  'popup.iframe-helpers.setBoxActive': _iframeHelpers.setBoxActive,
  'popup.iframe-helpers.isIframeVisible': _iframeHelpers.isIframeVisible,
  'popup.iframe-helpers.setSelectionMode': _iframeHelpers.setSelectionMode,
  'popup.utils.terminateNewExtension': function popupUtilsTerminateNewExtension() {
    (0, _iframeHelpers.removeIframe)();
    self.Remote.removeListener();
  },
  'popup.utils.checkPopupConnection': function popupUtilsCheckPopupConnection() {
    return 'alive';
  }
});
var _default = self.Remote;
exports.default = _default;

/***/ }),

/***/ 35:
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ 5:
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ 50:
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ 51:
/***/ (function(module, exports) {

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ 53:
/***/ (function(module, exports, __webpack_require__) {

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime = (function (exports) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] =
    GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return PromiseImpl.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0) PromiseImpl = Promise;

    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList),
      PromiseImpl
    );

    return exports.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        // Note: ["return"] must be used for ES3 parsing compatibility.
        if (delegate.iterator["return"]) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[toStringTagSymbol] = "Generator";

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  exports.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;

}(
  // If this script is executing as a CommonJS module, use module.exports
  // as the regeneratorRuntime namespace. Otherwise create a new empty
  // object. Either way, the resulting object will be used to initialize
  // the regeneratorRuntime variable at the top of this file.
   true ? module.exports : undefined
));

try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  Function("r", "regeneratorRuntime = r")(runtime);
}


/***/ }),

/***/ 56:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getPaperpileContentUrl = exports.GURU_API_URL = exports.NEW_WEBAPP_URL = exports.PLACK_URL = exports.PAPERPILE_API_URL = exports.ENVIRONMENT = void 0;
var paperpileApiUrl = 'http://127.0.0.1:4000';
var plackUrl = 'http://127.0.0.1:8080';
var newWebappUrl = 'http://127.0.0.1:6001';
var guruApiUrl = 'https://search.paperpile.com';
var ENVIRONMENT = "production" || false;
exports.ENVIRONMENT = ENVIRONMENT;

if (ENVIRONMENT === 'staging') {
  paperpileApiUrl = 'https://stage-api.paperpile.com';
  plackUrl = 'https://stage.paperpile.com';
  newWebappUrl = 'https://stage-beta.paperpile.com';
} else if (ENVIRONMENT === 'production') {
  paperpileApiUrl = 'https://api.paperpile.com';
  plackUrl = 'https://paperpile.com';
  newWebappUrl = 'https://paperpile.com';
}

var PAPERPILE_API_URL = paperpileApiUrl;
exports.PAPERPILE_API_URL = PAPERPILE_API_URL;
var PLACK_URL = plackUrl;
exports.PLACK_URL = PLACK_URL;
var NEW_WEBAPP_URL = newWebappUrl;
exports.NEW_WEBAPP_URL = NEW_WEBAPP_URL;
var GURU_API_URL = guruApiUrl;
exports.GURU_API_URL = GURU_API_URL;

var getPaperpileContentUrl = function getPaperpileContentUrl(env) {
  if (env === 'staging') {
    return 'https://stage.paperpile.com';
  }

  if (env === 'production') {
    return 'https://paperpile.com';
  }

  return 'http://localhost:5000';
};

exports.getPaperpileContentUrl = getPaperpileContentUrl;

/***/ }),

/***/ 66:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(5);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _classCallCheck2 = _interopRequireDefault(__webpack_require__(50));

var _createClass2 = _interopRequireDefault(__webpack_require__(51));

var _defineProperty2 = _interopRequireDefault(__webpack_require__(16));

var _config = __webpack_require__(56);

var Log = /*#__PURE__*/function () {
  function Log() {
    (0, _classCallCheck2.default)(this, Log);
    (0, _defineProperty2.default)(this, "debug", !!(_config.ENVIRONMENT && _config.ENVIRONMENT === 'development'));
  }

  (0, _createClass2.default)(Log, [{
    key: "log",
    value: function log(message) {
      if (this.debug) {
        var _console;

        for (var _len = arguments.length, optionalParams = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          optionalParams[_key - 1] = arguments[_key];
        }

        // eslint-disable-next-line no-console
        (_console = console).log.apply(_console, [message].concat(optionalParams));
      }
    }
  }]);
  return Log;
}();

exports.default = Log;

/***/ }),

/***/ 7:
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty;

/***/ }),

/***/ 745:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(5);

var _regenerator = _interopRequireDefault(__webpack_require__(20));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(21));

var _iframeHelpers = __webpack_require__(180);

var _Log = _interopRequireDefault(__webpack_require__(66));

var _remote = _interopRequireDefault(__webpack_require__(230));

// Special content script for injection in new Webapp
// Similar to cs-popup but much simplified
self.executionContext = 'cs';
self.Logger = new _Log.default();
var path =  true ? 'dist-new/' : undefined;
(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2() {
  var preexistingIframe, iframe;
  return _regenerator.default.wrap(function _callee2$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          // TODO: For some reason Safari injects this file multiple times
          // Chrome seems to also inject it if I open webapp in a new tab (2 tabs of webapp opened)
          preexistingIframe = document.getElementById('paperpile-iframe');

          if (!preexistingIframe) {
            _context2.next = 3;
            break;
          }

          return _context2.abrupt("return");

        case 3:
          (0, _iframeHelpers.removeIframe)();

          _remote.default.removeListener();
          /* This is to make sure that when the script is injected multiple times, it is only run when it was first injected */
          // self.Logger.log('#Webapp ContentScript execution started', chrome.runtime.getURL('iframe.html'));

          /* Next inject the iframe */


          iframe = document.createElement('iframe');
          iframe.src = chrome.runtime.getURL("".concat(path, "iframe.html"));
          iframe.style.display = 'none';
          iframe.style.position = 'fixed';
          iframe.style.background = 'transparent';
          iframe.style.top = '0';
          iframe.style.right = '0';
          iframe.style.boxSizing = 'border-box';
          iframe.style.border = 'none';
          iframe.width = '424';
          iframe.height = '302';
          iframe.style.zIndex = '9999999999';
          iframe.id = 'paperpile-iframe';
          iframe.style.maxHeight = '100%';
          document.body.appendChild(iframe);
          /* Once the Iframe is loaded we can send a message to the background page and we will now be sure
             that the Iframe will receive message from the background page since it is fully loaded */

          iframe.addEventListener('load', /*#__PURE__*/(0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee() {
            var getUserData, user, data, tabId, url;
            return _regenerator.default.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    /* Now setup message listener for background */
                    _remote.default.addListener();

                    _context.next = 3;
                    return _remote.default.bg.execute('utils.getUserFromDb');

                  case 3:
                    getUserData = _context.sent;
                    user = getUserData ? getUserData.result : null;
                    _context.next = 7;
                    return _remote.default.bg.execute('utils.getWebappTabId');

                  case 7:
                    data = _context.sent;
                    tabId = data === null || data === void 0 ? void 0 : data.result;
                    url = self.location.href;
                    self.Logger.log('#WEBAPP POPUP');
                    _context.next = 13;
                    return _remote.default.popup.execute('render.renderApp', tabId, {
                      url: url,
                      user: user,
                      tabId: tabId,
                      isWebapp: true,
                      source: 'single',
                      importSupported: false
                    });

                  case 13:
                    document.addEventListener('click', function () {
                      (0, _iframeHelpers.hideIframe)();
                    });

                  case 14:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee);
          })), true);

        case 21:
        case "end":
          return _context2.stop();
      }
    }
  }, _callee2);
}))();

/***/ }),

/***/ 81:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(2);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _regenerator = _interopRequireDefault(__webpack_require__(9));

var _asyncToGenerator2 = _interopRequireDefault(__webpack_require__(10));

var _typeof2 = _interopRequireDefault(__webpack_require__(35));

var _classCallCheck2 = _interopRequireDefault(__webpack_require__(12));

var _createClass2 = _interopRequireDefault(__webpack_require__(13));

var _defineProperty2 = _interopRequireDefault(__webpack_require__(7));

var _uuid = __webpack_require__(95);

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
  Communication bridges this class handles:
  - webapp <-> sw
  - webapp <-> cs

  - bg <-> cs
  - bg <-> popup

  Message needs to pass via relay Remote classes like this:
  - sw <-> webapp <-> cs <-> bg <-> cs (other tab)

  On Safari popup bridge works as follows:
  - popup <-> cs

  Notes:
  - when 'cs' broadcasts, it's also heard by 'popup', but 'popup' should only accept messages from 'bg' (in Chrome),
    so if Chrome 'cs' sends a message to 'popup':
      1) 'popup' will hear it (and ignore it),
      2) 'bg' will also hear it and relay it to 'popup' (with correct tabId)
    if Safari 'cs' sends a message to 'popup':
      1) 'popup' will get it directly using iframe postMessage
 */
var Remote = /*#__PURE__*/function () {
  function Remote(options) {
    var _this = this;

    (0, _classCallCheck2.default)(this, Remote);
    (0, _defineProperty2.default)(this, "origin", void 0);
    (0, _defineProperty2.default)(this, "tabId", void 0);
    (0, _defineProperty2.default)(this, "actions", void 0);
    (0, _defineProperty2.default)(this, "logger", void 0);
    (0, _defineProperty2.default)(this, "listenerAttached", false);
    (0, _defineProperty2.default)(this, "messageCache", {});
    (0, _defineProperty2.default)(this, "onMessageCallback", this.onMessage.bind(this));
    (0, _defineProperty2.default)(this, "onEventListenerMessageCallback", this.onEventListenerMessage.bind(this));
    (0, _defineProperty2.default)(this, "bg", {
      execute: function execute() {
        var functionName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
        var tabId = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
        var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        return _this.sendMessage('bg', tabId, functionName, _objectSpread({}, data));
      }
    });
    (0, _defineProperty2.default)(this, 'cs', {
      execute: function execute() {
        var functionName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
        var tabId = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
        var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        return _this.sendMessage('cs', tabId, functionName, _objectSpread({}, data));
      }
    });
    (0, _defineProperty2.default)(this, "popup", {
      execute: function execute() {
        var functionName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
        var tabId = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
        var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        return _this.sendMessage('popup', tabId, functionName, _objectSpread({}, data));
      }
    });
    (0, _defineProperty2.default)(this, "webapp", {
      execute: function execute() {
        var functionName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
        var tabId = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
        var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        return _this.sendMessage('webapp', tabId, functionName, _objectSpread({}, data));
      }
    });
    (0, _defineProperty2.default)(this, "sw", {
      execute: function execute() {
        var functionName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
        var tabId = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
        var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
        return _this.sendMessage('sw', tabId, functionName, _objectSpread({}, data));
      }
    });
    this.origin = options.origin;
    this.actions = options.actions || {};
    this.logger = options.logger || {
      log: console.log
    };

    this.actions['remote.test-connection'] = function () {
      return "".concat(_this.origin, " connection alive");
    };
  }

  (0, _createClass2.default)(Remote, [{
    key: "addListener",
    value: function addListener() {
      if (this.origin === 'sw') throw new Error('Use serviceWorker specific class ServiceWorkerRemote.ts');

      if (self.executionContext && self.executionContext !== this.origin || this.listenerAttached) {
        this.logger.log("Error adding message listener to ".concat(this.origin, " context - possible duplicate"), {
          executionContext: self.executionContext,
          listenerAttached: this.listenerAttached
        });
        return;
      }

      if (this.origin === 'webapp' || this.origin === 'cs' ||  false && false) {
        self.addEventListener('message', this.onEventListenerMessageCallback, false);
      }

      if (this.origin === 'webapp') {
        navigator.serviceWorker.addEventListener('message', this.onEventListenerMessageCallback);
      }

      if (this.origin !== 'webapp') {
        chrome.runtime.onMessage.addListener(this.onMessageCallback);
      }

      this.listenerAttached = true;
    }
  }, {
    key: "removeListener",
    value: function removeListener() {
      if (this.origin === 'webapp' || this.origin === 'cs' ||  false && false) {
        self.removeEventListener('message', this.onEventListenerMessageCallback, false);
      }

      if (this.origin === 'webapp') {
        navigator.serviceWorker.removeEventListener('message', this.onEventListenerMessageCallback);
      }

      if (this.origin !== 'webapp') {
        chrome.runtime.onMessage.removeListener(this.onMessageCallback);
      }
    }
  }, {
    key: "addActions",
    value: function addActions(actions) {
      Object.assign(this.actions, actions);
    }
  }, {
    key: "onMessage",
    value: function onMessage(msg, sender, sendResponse) {
      this.logger.log("[".concat(this.origin, "] onMessage: "), msg);

      if ((0, _typeof2.default)(msg) !== 'object' || typeof msg.origin !== 'string' || typeof msg.target !== 'string') {
        return false;
      } // We need to return data as a `sendResponse` call as returning a promise
      // and calling `resolve` on it does not seem to work correctly on latest Chrome
      //
      // @see https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage
      // sendResponse description


      var isMessageToRelay = this.origin === 'bg' && msg.origin !== 'bg' || this.origin === 'cs' && (['webapp', 'sw'].includes(msg.target) ||  false && false);
      var isMessageToHandle;

      if (false) { var forcePopupToAnswerToBGOnly; } else {
        var isMessageSentByBG = sender.origin === 'null' || this.origin !== 'popup';
        isMessageToHandle = msg.target === this.origin && isMessageSentByBG;
      }

      var needToProcess = isMessageToRelay || isMessageToHandle;

      if (needToProcess) {
        this.processMessage(msg, sender, sendResponse); // fire off promise
      }

      return !!needToProcess;
    }
    /**
     * Event handler hooked up within:
     *   - webapp
     *   - cs-popup
     *
     * Note: Any `postMessage` will get handled by all `onEventListenerMessage` callbacks,
     *       including the sender's callback.
     */

  }, {
    key: "onEventListenerMessage",
    value: function () {
      var _onEventListenerMessage = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee(event) {
        var message, _message$action, action, _result, successResponse, _iframe$contentWindow, iframe, client, actionNotRecognizedResponse, _iframe$contentWindow2, _iframe, _client, result, relayMessage, _iframe2$contentWindo, _iframe2, _client2;

        return _regenerator.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(this.origin !== 'webapp' && this.origin !== 'cs' && this.origin !== 'popup')) {
                  _context.next = 2;
                  break;
                }

                throw new Error('Unexpected origin');

              case 2:
                this.logger.log("[".concat(this.origin, "] onEventListenerMessage: "), event.data);

                if (!(!event || (0, _typeof2.default)(event.data) !== 'object' || typeof event.data.origin !== 'string' || typeof event.data.target !== 'string')) {
                  _context.next = 5;
                  break;
                }

                return _context.abrupt("return");

              case 5:
                message = event.data;

                if (!(!message.id || !message.origin || !message.target)) {
                  _context.next = 8;
                  break;
                }

                return _context.abrupt("return");

              case 8:
                if (!(this.origin === 'webapp' && message.origin === 'popup')) {
                  _context.next = 10;
                  break;
                }

                return _context.abrupt("return");

              case 10:
                if (!(message.origin === this.origin)) {
                  _context.next = 12;
                  break;
                }

                return _context.abrupt("return");

              case 12:
                if (!(message.target === this.origin)) {
                  _context.next = 52;
                  break;
                }

                if (!this.messageCache[message.id]) {
                  _context.next = 17;
                  break;
                }

                this.messageCache[message.id](message.data);
                delete this.messageCache[message.id];
                return _context.abrupt("return");

              case 17:
                action = (_message$action = message.action) === null || _message$action === void 0 ? void 0 : _message$action.replace(new RegExp("^".concat(Remote.ACTION_PREFIX, "-"), ''), '');

                if (!(action && action in this.actions)) {
                  _context.next = 37;
                  break;
                }

                _context.next = 21;
                return this.actions[action](message.data);

              case 21:
                _result = _context.sent;
                successResponse = {
                  type: 'remote-message',
                  origin: this.origin,
                  target: message.origin,
                  action: message.action,
                  id: message.id,
                  tabId: message.tabId,
                  data: {
                    error: null,
                    result: _result
                  }
                };

                if (!(this.origin === 'popup' && "chrome" === 'safari')) {
                  _context.next = 27;
                  break;
                }

                self.parent.postMessage(successResponse, '*');
                _context.next = 36;
                break;

              case 27:
                if (!(this.origin === 'cs' && message.origin === 'popup' && "chrome" === 'safari')) {
                  _context.next = 32;
                  break;
                }

                iframe = document.getElementById('paperpile-iframe');
                iframe === null || iframe === void 0 ? void 0 : (_iframe$contentWindow = iframe.contentWindow) === null || _iframe$contentWindow === void 0 ? void 0 : _iframe$contentWindow.postMessage(successResponse, '*');
                _context.next = 36;
                break;

              case 32:
                client = event.source;

                if (client) {
                  _context.next = 35;
                  break;
                }

                return _context.abrupt("return");

              case 35:
                if ('scriptURL' in client) {
                  // Service Worker
                  client.postMessage(successResponse, []);
                } else {
                  client.postMessage(successResponse, '*');
                }

              case 36:
                return _context.abrupt("return");

              case 37:
                actionNotRecognizedResponse = {
                  type: 'remote-message',
                  origin: this.origin,
                  target: message.origin,
                  action: message.action,
                  id: message.id,
                  tabId: message.tabId,
                  data: {
                    error: 'action not recognized',
                    result: null
                  }
                };

                if (!(this.origin === 'popup' && "chrome" === 'safari')) {
                  _context.next = 42;
                  break;
                }

                self.parent.postMessage(actionNotRecognizedResponse, '*');
                _context.next = 51;
                break;

              case 42:
                if (!(this.origin === 'cs' && message.origin === 'popup' && "chrome" === 'safari')) {
                  _context.next = 47;
                  break;
                }

                _iframe = document.getElementById('paperpile-iframe');
                _iframe === null || _iframe === void 0 ? void 0 : (_iframe$contentWindow2 = _iframe.contentWindow) === null || _iframe$contentWindow2 === void 0 ? void 0 : _iframe$contentWindow2.postMessage(actionNotRecognizedResponse, '*');
                _context.next = 51;
                break;

              case 47:
                _client = event.source;

                if (_client) {
                  _context.next = 50;
                  break;
                }

                return _context.abrupt("return");

              case 50:
                if ('scriptURL' in _client) {
                  // Service Worker
                  _client.postMessage(actionNotRecognizedResponse, []);
                } else {
                  _client.postMessage(actionNotRecognizedResponse, '*');
                }

              case 51:
                return _context.abrupt("return");

              case 52:
                if (!(this.origin === 'popup')) {
                  _context.next = 54;
                  break;
                }

                return _context.abrupt("return");

              case 54:
                _context.next = 56;
                return this[message.target].execute(message.action, message.tabId, message.data);

              case 56:
                result = _context.sent;
                relayMessage = {
                  type: 'remote-message',
                  origin: this.origin,
                  target: message.origin,
                  action: message.action,
                  id: message.id,
                  tabId: message.tabId,
                  data: result
                };

                if (!(this.origin === 'cs' && message.origin === 'popup' && "chrome" === 'safari')) {
                  _context.next = 63;
                  break;
                }

                _iframe2 = document.getElementById('paperpile-iframe');
                _iframe2 === null || _iframe2 === void 0 ? void 0 : (_iframe2$contentWindo = _iframe2.contentWindow) === null || _iframe2$contentWindo === void 0 ? void 0 : _iframe2$contentWindo.postMessage(relayMessage, '*');
                _context.next = 67;
                break;

              case 63:
                _client2 = event.source;

                if (_client2) {
                  _context.next = 66;
                  break;
                }

                return _context.abrupt("return");

              case 66:
                if ('scriptURL' in _client2) {
                  // Service Worker
                  _client2.postMessage(relayMessage, []);
                } else {
                  _client2.postMessage(relayMessage, '*');
                }

              case 67:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onEventListenerMessage(_x) {
        return _onEventListenerMessage.apply(this, arguments);
      }

      return onEventListenerMessage;
    }()
  }, {
    key: "processMessage",
    value: function () {
      var _processMessage = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee2(message, sender, sendResponse) {
        var _sender$tab;

        var _result2, tabId, msgName, result;

        return _regenerator.default.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(message.target !== this.origin)) {
                  _context2.next = 5;
                  break;
                }

                _context2.next = 3;
                return this[message.target].execute(message.action, message.tabId, message.data);

              case 3:
                _result2 = _context2.sent;
                return _context2.abrupt("return", sendResponse(_result2));

              case 5:
                if (message.action) {
                  _context2.next = 7;
                  break;
                }

                return _context2.abrupt("return", sendResponse({
                  result: null,
                  error: 'no action'
                }));

              case 7:
                tabId = (sender === null || sender === void 0 ? void 0 : (_sender$tab = sender.tab) === null || _sender$tab === void 0 ? void 0 : _sender$tab.id) ? sender.tab.id : message.tabId;

                if (tabId) {
                  _context2.next = 10;
                  break;
                }

                return _context2.abrupt("return", sendResponse({
                  result: null,
                  error: 'no tab id defined'
                }));

              case 10:
                msgName = message.action.replace(new RegExp("^".concat(Remote.ACTION_PREFIX, "-"), ''), '');

                if (this.actions[msgName]) {
                  _context2.next = 13;
                  break;
                }

                return _context2.abrupt("return", sendResponse({
                  result: null,
                  error: 'action not recognized'
                }));

              case 13:
                _context2.next = 15;
                return this.actions[msgName](_objectSpread(_objectSpread({}, message.data), {}, {
                  tabId: tabId
                }));

              case 15:
                result = _context2.sent;
                return _context2.abrupt("return", sendResponse({
                  result: result,
                  error: null
                }));

              case 17:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function processMessage(_x2, _x3, _x4) {
        return _processMessage.apply(this, arguments);
      }

      return processMessage;
    }()
  }, {
    key: "sendMessage",
    value: function () {
      var _sendMessage = (0, _asyncToGenerator2.default)( /*#__PURE__*/_regenerator.default.mark(function _callee3(target, tabId, action, dataToSend) {
        var _this2 = this;

        var actionMsg, result, message, promise, _promise, _promise3, _promise2, _promise4;

        return _regenerator.default.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                this.logger.log("[".concat(this.origin, "] sendMessage"), {
                  target: target,
                  tabId: tabId,
                  action: action,
                  dataToSend: dataToSend
                });

                if (!(this.origin === 'sw')) {
                  _context3.next = 3;
                  break;
                }

                throw new Error('Unexpected origin');

              case 3:
                if (!(this.origin === target)) {
                  _context3.next = 10;
                  break;
                }

                actionMsg = action.replace(new RegExp("^".concat(Remote.ACTION_PREFIX, "-"), ''), '');

                if (!(actionMsg && actionMsg in this.actions)) {
                  _context3.next = 10;
                  break;
                }

                _context3.next = 8;
                return this.actions[actionMsg](dataToSend);

              case 8:
                result = _context3.sent;
                return _context3.abrupt("return", {
                  result: result,
                  error: null
                });

              case 10:
                message = {
                  type: 'remote-message',
                  origin: this.origin,
                  target: target,
                  action: action.startsWith(Remote.ACTION_PREFIX) ? action : "".concat(Remote.ACTION_PREFIX, "-").concat(action),
                  tabId: tabId,
                  data: dataToSend
                };

                if (!(this.origin === 'webapp')) {
                  _context3.next = 14;
                  break;
                }

                promise = new Promise(function (resolve) {
                  message.id = (0, _uuid.v4)();
                  _this2.messageCache[message.id] = resolve;

                  if (target === 'sw') {
                    var _navigator$serviceWor;

                    (_navigator$serviceWor = navigator.serviceWorker.controller) === null || _navigator$serviceWor === void 0 ? void 0 : _navigator$serviceWor.postMessage(message);
                  } else {
                    self.postMessage(message, '*');
                  }
                });
                return _context3.abrupt("return", promise);

              case 14:
                if (!(this.origin === 'cs')) {
                  _context3.next = 28;
                  break;
                }

                if (!(target === 'webapp' || target === 'sw')) {
                  _context3.next = 18;
                  break;
                }

                _promise = new Promise(function (resolve) {
                  message.id = (0, _uuid.v4)();
                  _this2.messageCache[message.id] = resolve;
                  self.postMessage(message, '*');
                });
                return _context3.abrupt("return", _promise);

              case 18:
                if (!(target === 'popup')) {
                  _context3.next = 24;
                  break;
                }

                if (true) {
                  _context3.next = 22;
                  break;
                }

                _promise3 = new Promise(function (resolve) {
                  var _iframe$contentWindow3;

                  message.id = (0, _uuid.v4)();
                  _this2.messageCache[message.id] = resolve;
                  var iframe = document.getElementById('paperpile-iframe');
                  iframe === null || iframe === void 0 ? void 0 : (_iframe$contentWindow3 = iframe.contentWindow) === null || _iframe$contentWindow3 === void 0 ? void 0 : _iframe$contentWindow3.postMessage(message, '*');
                });
                return _context3.abrupt("return", _promise3);

              case 22:
                _promise2 = new Promise(function (resolve) {
                  message.id = (0, _uuid.v4)();
                  _this2.messageCache[message.id] = resolve;
                  chrome.runtime.sendMessage(message, function (data) {
                    if (chrome.runtime.lastError) {
                      // means there is no receiver available
                      resolve(undefined);
                    } else {
                      // this.logger.log('Remote send tabs message', data);
                      resolve(data);
                    }
                  });
                });
                return _context3.abrupt("return", _promise2);

              case 24:
                if (!(target === 'bg')) {
                  _context3.next = 26;
                  break;
                }

                return _context3.abrupt("return", new Promise(function (resolve) {
                  chrome.runtime.sendMessage(message, function (data) {
                    if (chrome.runtime.lastError) {
                      // means there is no receiver available
                      resolve(undefined);
                    } else {
                      // this.logger.log('Remote send tabs message', data);
                      resolve(data);
                    }
                  });
                }));

              case 26:
                this.logger.log('Error sending message, target not recognized');
                return _context3.abrupt("return", Promise.resolve({
                  result: null,
                  error: 'unexpected target in cs'
                }));

              case 28:
                if (!(this.origin === 'popup')) {
                  _context3.next = 38;
                  break;
                }

                if (true) {
                  _context3.next = 32;
                  break;
                }

                _promise4 = new Promise(function (resolve) {
                  message.id = (0, _uuid.v4)();
                  _this2.messageCache[message.id] = resolve;
                  self.parent.postMessage(message, '*');
                });
                return _context3.abrupt("return", _promise4);

              case 32:
                if (!(target === 'bg')) {
                  _context3.next = 34;
                  break;
                }

                return _context3.abrupt("return", new Promise(function (resolve) {
                  chrome.runtime.sendMessage(message, function (data) {
                    if (chrome.runtime.lastError) {
                      // means there is no receiver available
                      resolve(undefined);
                    } else {
                      resolve(data);
                    }
                  });
                }));

              case 34:
                if (tabId) {
                  _context3.next = 37;
                  break;
                }

                this.logger.log('Error sending message, target is tab but tabId was not provided');
                return _context3.abrupt("return", Promise.resolve({
                  result: null,
                  error: 'incorrect use of sendMessage'
                }));

              case 37:
                return _context3.abrupt("return", new Promise(function (resolve) {
                  chrome.tabs.sendMessage(tabId, message, function (data) {
                    if (chrome.runtime.lastError) {
                      // means there is no receiver available
                      resolve(undefined);
                    } else {
                      resolve(data);
                    }
                  });
                }));

              case 38:
                if (tabId) {
                  _context3.next = 41;
                  break;
                }

                this.logger.log('Error sending message, target is tab but tabId was not provided');
                return _context3.abrupt("return", Promise.resolve({
                  result: null,
                  error: 'incorrect use of sendMessage'
                }));

              case 41:
                return _context3.abrupt("return", new Promise(function (resolve) {
                  chrome.tabs.sendMessage(tabId, message, function (data) {
                    if (chrome.runtime.lastError) {
                      // means there is no receiver available
                      resolve(undefined);
                    } else {
                      resolve(data);
                    }
                  });
                }));

              case 42:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function sendMessage(_x5, _x6, _x7, _x8) {
        return _sendMessage.apply(this, arguments);
      }

      return sendMessage;
    }()
  }]);
  return Remote;
}();

exports.default = Remote;
(0, _defineProperty2.default)(Remote, "ACTION_PREFIX", 'new');

/***/ }),

/***/ 9:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(53);


/***/ }),

/***/ 95:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "v1", function() { return /* reexport */ esm_browser_v1; });
__webpack_require__.d(__webpack_exports__, "v3", function() { return /* reexport */ esm_browser_v3; });
__webpack_require__.d(__webpack_exports__, "v4", function() { return /* reexport */ esm_browser_v4; });
__webpack_require__.d(__webpack_exports__, "v5", function() { return /* reexport */ esm_browser_v5; });
__webpack_require__.d(__webpack_exports__, "NIL", function() { return /* reexport */ nil; });
__webpack_require__.d(__webpack_exports__, "version", function() { return /* reexport */ esm_browser_version; });
__webpack_require__.d(__webpack_exports__, "validate", function() { return /* reexport */ esm_browser_validate; });
__webpack_require__.d(__webpack_exports__, "stringify", function() { return /* reexport */ esm_browser_stringify; });
__webpack_require__.d(__webpack_exports__, "parse", function() { return /* reexport */ esm_browser_parse; });

// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/rng.js
// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
var getRandomValues;
var rnds8 = new Uint8Array(16);
function rng() {
  // lazy load so that environments that need to polyfill have a chance to do so
  if (!getRandomValues) {
    // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation. Also,
    // find the complete implementation of crypto (msCrypto) on IE11.
    getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto !== 'undefined' && typeof msCrypto.getRandomValues === 'function' && msCrypto.getRandomValues.bind(msCrypto);

    if (!getRandomValues) {
      throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
    }
  }

  return getRandomValues(rnds8);
}
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/regex.js
/* harmony default export */ var regex = (/^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/validate.js


function validate(uuid) {
  return typeof uuid === 'string' && regex.test(uuid);
}

/* harmony default export */ var esm_browser_validate = (validate);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/stringify.js

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */

var byteToHex = [];

for (var stringify_i = 0; stringify_i < 256; ++stringify_i) {
  byteToHex.push((stringify_i + 0x100).toString(16).substr(1));
}

function stringify(arr) {
  var offset = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  var uuid = (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase(); // Consistency check for valid UUID.  If this throws, it's likely due to one
  // of the following:
  // - One or more input array values don't map to a hex octet (leading to
  // "undefined" in the uuid)
  // - Invalid input values for the RFC `version` or `variant` fields

  if (!esm_browser_validate(uuid)) {
    throw TypeError('Stringified UUID is invalid');
  }

  return uuid;
}

/* harmony default export */ var esm_browser_stringify = (stringify);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/v1.js

 // **`v1()` - Generate time-based UUID**
//
// Inspired by https://github.com/LiosK/UUID.js
// and http://docs.python.org/library/uuid.html

var _nodeId;

var _clockseq; // Previous uuid creation time


var _lastMSecs = 0;
var _lastNSecs = 0; // See https://github.com/uuidjs/uuid for API details

function v1(options, buf, offset) {
  var i = buf && offset || 0;
  var b = buf || new Array(16);
  options = options || {};
  var node = options.node || _nodeId;
  var clockseq = options.clockseq !== undefined ? options.clockseq : _clockseq; // node and clockseq need to be initialized to random values if they're not
  // specified.  We do this lazily to minimize issues related to insufficient
  // system entropy.  See #189

  if (node == null || clockseq == null) {
    var seedBytes = options.random || (options.rng || rng)();

    if (node == null) {
      // Per 4.5, create and 48-bit node id, (47 random bits + multicast bit = 1)
      node = _nodeId = [seedBytes[0] | 0x01, seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
    }

    if (clockseq == null) {
      // Per 4.2.2, randomize (14 bit) clockseq
      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 0x3fff;
    }
  } // UUID timestamps are 100 nano-second units since the Gregorian epoch,
  // (1582-10-15 00:00).  JSNumbers aren't precise enough for this, so
  // time is handled internally as 'msecs' (integer milliseconds) and 'nsecs'
  // (100-nanoseconds offset from msecs) since unix epoch, 1970-01-01 00:00.


  var msecs = options.msecs !== undefined ? options.msecs : Date.now(); // Per 4.2.1.2, use count of uuid's generated during the current clock
  // cycle to simulate higher resolution clock

  var nsecs = options.nsecs !== undefined ? options.nsecs : _lastNSecs + 1; // Time since last uuid creation (in msecs)

  var dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 10000; // Per 4.2.1.2, Bump clockseq on clock regression

  if (dt < 0 && options.clockseq === undefined) {
    clockseq = clockseq + 1 & 0x3fff;
  } // Reset nsecs if clock regresses (new clockseq) or we've moved onto a new
  // time interval


  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === undefined) {
    nsecs = 0;
  } // Per 4.2.1.2 Throw error if too many uuids are requested


  if (nsecs >= 10000) {
    throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
  }

  _lastMSecs = msecs;
  _lastNSecs = nsecs;
  _clockseq = clockseq; // Per 4.1.4 - Convert from unix epoch to Gregorian epoch

  msecs += 12219292800000; // `time_low`

  var tl = ((msecs & 0xfffffff) * 10000 + nsecs) % 0x100000000;
  b[i++] = tl >>> 24 & 0xff;
  b[i++] = tl >>> 16 & 0xff;
  b[i++] = tl >>> 8 & 0xff;
  b[i++] = tl & 0xff; // `time_mid`

  var tmh = msecs / 0x100000000 * 10000 & 0xfffffff;
  b[i++] = tmh >>> 8 & 0xff;
  b[i++] = tmh & 0xff; // `time_high_and_version`

  b[i++] = tmh >>> 24 & 0xf | 0x10; // include version

  b[i++] = tmh >>> 16 & 0xff; // `clock_seq_hi_and_reserved` (Per 4.2.2 - include variant)

  b[i++] = clockseq >>> 8 | 0x80; // `clock_seq_low`

  b[i++] = clockseq & 0xff; // `node`

  for (var n = 0; n < 6; ++n) {
    b[i + n] = node[n];
  }

  return buf || esm_browser_stringify(b);
}

/* harmony default export */ var esm_browser_v1 = (v1);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/parse.js


function parse(uuid) {
  if (!esm_browser_validate(uuid)) {
    throw TypeError('Invalid UUID');
  }

  var v;
  var arr = new Uint8Array(16); // Parse ########-....-....-....-............

  arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
  arr[1] = v >>> 16 & 0xff;
  arr[2] = v >>> 8 & 0xff;
  arr[3] = v & 0xff; // Parse ........-####-....-....-............

  arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
  arr[5] = v & 0xff; // Parse ........-....-####-....-............

  arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
  arr[7] = v & 0xff; // Parse ........-....-....-####-............

  arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
  arr[9] = v & 0xff; // Parse ........-....-....-....-############
  // (Use "/" to avoid 32-bit truncation when bit-shifting high-order bytes)

  arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 0x10000000000 & 0xff;
  arr[11] = v / 0x100000000 & 0xff;
  arr[12] = v >>> 24 & 0xff;
  arr[13] = v >>> 16 & 0xff;
  arr[14] = v >>> 8 & 0xff;
  arr[15] = v & 0xff;
  return arr;
}

/* harmony default export */ var esm_browser_parse = (parse);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/v35.js



function stringToBytes(str) {
  str = unescape(encodeURIComponent(str)); // UTF8 escape

  var bytes = [];

  for (var i = 0; i < str.length; ++i) {
    bytes.push(str.charCodeAt(i));
  }

  return bytes;
}

var DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
var URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';
/* harmony default export */ var v35 = (function (name, version, hashfunc) {
  function generateUUID(value, namespace, buf, offset) {
    if (typeof value === 'string') {
      value = stringToBytes(value);
    }

    if (typeof namespace === 'string') {
      namespace = esm_browser_parse(namespace);
    }

    if (namespace.length !== 16) {
      throw TypeError('Namespace must be array-like (16 iterable integer values, 0-255)');
    } // Compute hash of namespace and value, Per 4.3
    // Future: Use spread syntax when supported on all platforms, e.g. `bytes =
    // hashfunc([...namespace, ... value])`


    var bytes = new Uint8Array(16 + value.length);
    bytes.set(namespace);
    bytes.set(value, namespace.length);
    bytes = hashfunc(bytes);
    bytes[6] = bytes[6] & 0x0f | version;
    bytes[8] = bytes[8] & 0x3f | 0x80;

    if (buf) {
      offset = offset || 0;

      for (var i = 0; i < 16; ++i) {
        buf[offset + i] = bytes[i];
      }

      return buf;
    }

    return esm_browser_stringify(bytes);
  } // Function#name is not settable on some platforms (#270)


  try {
    generateUUID.name = name; // eslint-disable-next-line no-empty
  } catch (err) {} // For CommonJS default export support


  generateUUID.DNS = DNS;
  generateUUID.URL = URL;
  return generateUUID;
});
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/md5.js
/*
 * Browser-compatible JavaScript MD5
 *
 * Modification of JavaScript MD5
 * https://github.com/blueimp/JavaScript-MD5
 *
 * Copyright 2011, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 *
 * Based on
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.2 Copyright (C) Paul Johnston 1999 - 2009
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */
function md5(bytes) {
  if (typeof bytes === 'string') {
    var msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

    bytes = new Uint8Array(msg.length);

    for (var i = 0; i < msg.length; ++i) {
      bytes[i] = msg.charCodeAt(i);
    }
  }

  return md5ToHexEncodedArray(wordsToMd5(bytesToWords(bytes), bytes.length * 8));
}
/*
 * Convert an array of little-endian words to an array of bytes
 */


function md5ToHexEncodedArray(input) {
  var output = [];
  var length32 = input.length * 32;
  var hexTab = '0123456789abcdef';

  for (var i = 0; i < length32; i += 8) {
    var x = input[i >> 5] >>> i % 32 & 0xff;
    var hex = parseInt(hexTab.charAt(x >>> 4 & 0x0f) + hexTab.charAt(x & 0x0f), 16);
    output.push(hex);
  }

  return output;
}
/**
 * Calculate output length with padding and bit length
 */


function getOutputLength(inputLength8) {
  return (inputLength8 + 64 >>> 9 << 4) + 14 + 1;
}
/*
 * Calculate the MD5 of an array of little-endian words, and a bit length.
 */


function wordsToMd5(x, len) {
  /* append padding */
  x[len >> 5] |= 0x80 << len % 32;
  x[getOutputLength(len) - 1] = len;
  var a = 1732584193;
  var b = -271733879;
  var c = -1732584194;
  var d = 271733878;

  for (var i = 0; i < x.length; i += 16) {
    var olda = a;
    var oldb = b;
    var oldc = c;
    var oldd = d;
    a = md5ff(a, b, c, d, x[i], 7, -680876936);
    d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
    c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
    b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
    d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
    c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
    b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
    d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
    c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
    b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
    d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
    c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
    b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
    d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
    c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
    b = md5gg(b, c, d, a, x[i], 20, -373897302);
    a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
    d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
    c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
    b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
    d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
    c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
    b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
    d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
    c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
    b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
    d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
    c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
    b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
    d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
    c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
    b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
    d = md5hh(d, a, b, c, x[i], 11, -358537222);
    c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
    b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
    d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
    c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
    b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = md5ii(a, b, c, d, x[i], 6, -198630844);
    d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
    c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
    b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
    d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
    c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
    b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
    d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
    c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
    b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
    d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
    c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
    b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = safeAdd(a, olda);
    b = safeAdd(b, oldb);
    c = safeAdd(c, oldc);
    d = safeAdd(d, oldd);
  }

  return [a, b, c, d];
}
/*
 * Convert an array bytes to an array of little-endian words
 * Characters >255 have their high-byte silently ignored.
 */


function bytesToWords(input) {
  if (input.length === 0) {
    return [];
  }

  var length8 = input.length * 8;
  var output = new Uint32Array(getOutputLength(length8));

  for (var i = 0; i < length8; i += 8) {
    output[i >> 5] |= (input[i / 8] & 0xff) << i % 32;
  }

  return output;
}
/*
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally
 * to work around bugs in some JS interpreters.
 */


function safeAdd(x, y) {
  var lsw = (x & 0xffff) + (y & 0xffff);
  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return msw << 16 | lsw & 0xffff;
}
/*
 * Bitwise rotate a 32-bit number to the left.
 */


function bitRotateLeft(num, cnt) {
  return num << cnt | num >>> 32 - cnt;
}
/*
 * These functions implement the four basic operations the algorithm uses.
 */


function md5cmn(q, a, b, x, s, t) {
  return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}

function md5ff(a, b, c, d, x, s, t) {
  return md5cmn(b & c | ~b & d, a, b, x, s, t);
}

function md5gg(a, b, c, d, x, s, t) {
  return md5cmn(b & d | c & ~d, a, b, x, s, t);
}

function md5hh(a, b, c, d, x, s, t) {
  return md5cmn(b ^ c ^ d, a, b, x, s, t);
}

function md5ii(a, b, c, d, x, s, t) {
  return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}

/* harmony default export */ var esm_browser_md5 = (md5);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/v3.js


var v3 = v35('v3', 0x30, esm_browser_md5);
/* harmony default export */ var esm_browser_v3 = (v3);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/v4.js



function v4(options, buf, offset) {
  options = options || {};
  var rnds = options.random || (options.rng || rng)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    offset = offset || 0;

    for (var i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }

    return buf;
  }

  return esm_browser_stringify(rnds);
}

/* harmony default export */ var esm_browser_v4 = (v4);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/sha1.js
// Adapted from Chris Veness' SHA1 code at
// http://www.movable-type.co.uk/scripts/sha1.html
function f(s, x, y, z) {
  switch (s) {
    case 0:
      return x & y ^ ~x & z;

    case 1:
      return x ^ y ^ z;

    case 2:
      return x & y ^ x & z ^ y & z;

    case 3:
      return x ^ y ^ z;
  }
}

function ROTL(x, n) {
  return x << n | x >>> 32 - n;
}

function sha1(bytes) {
  var K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];
  var H = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];

  if (typeof bytes === 'string') {
    var msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

    bytes = [];

    for (var i = 0; i < msg.length; ++i) {
      bytes.push(msg.charCodeAt(i));
    }
  } else if (!Array.isArray(bytes)) {
    // Convert Array-like to Array
    bytes = Array.prototype.slice.call(bytes);
  }

  bytes.push(0x80);
  var l = bytes.length / 4 + 2;
  var N = Math.ceil(l / 16);
  var M = new Array(N);

  for (var _i = 0; _i < N; ++_i) {
    var arr = new Uint32Array(16);

    for (var j = 0; j < 16; ++j) {
      arr[j] = bytes[_i * 64 + j * 4] << 24 | bytes[_i * 64 + j * 4 + 1] << 16 | bytes[_i * 64 + j * 4 + 2] << 8 | bytes[_i * 64 + j * 4 + 3];
    }

    M[_i] = arr;
  }

  M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
  M[N - 1][14] = Math.floor(M[N - 1][14]);
  M[N - 1][15] = (bytes.length - 1) * 8 & 0xffffffff;

  for (var _i2 = 0; _i2 < N; ++_i2) {
    var W = new Uint32Array(80);

    for (var t = 0; t < 16; ++t) {
      W[t] = M[_i2][t];
    }

    for (var _t = 16; _t < 80; ++_t) {
      W[_t] = ROTL(W[_t - 3] ^ W[_t - 8] ^ W[_t - 14] ^ W[_t - 16], 1);
    }

    var a = H[0];
    var b = H[1];
    var c = H[2];
    var d = H[3];
    var e = H[4];

    for (var _t2 = 0; _t2 < 80; ++_t2) {
      var s = Math.floor(_t2 / 20);
      var T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[_t2] >>> 0;
      e = d;
      d = c;
      c = ROTL(b, 30) >>> 0;
      b = a;
      a = T;
    }

    H[0] = H[0] + a >>> 0;
    H[1] = H[1] + b >>> 0;
    H[2] = H[2] + c >>> 0;
    H[3] = H[3] + d >>> 0;
    H[4] = H[4] + e >>> 0;
  }

  return [H[0] >> 24 & 0xff, H[0] >> 16 & 0xff, H[0] >> 8 & 0xff, H[0] & 0xff, H[1] >> 24 & 0xff, H[1] >> 16 & 0xff, H[1] >> 8 & 0xff, H[1] & 0xff, H[2] >> 24 & 0xff, H[2] >> 16 & 0xff, H[2] >> 8 & 0xff, H[2] & 0xff, H[3] >> 24 & 0xff, H[3] >> 16 & 0xff, H[3] >> 8 & 0xff, H[3] & 0xff, H[4] >> 24 & 0xff, H[4] >> 16 & 0xff, H[4] >> 8 & 0xff, H[4] & 0xff];
}

/* harmony default export */ var esm_browser_sha1 = (sha1);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/v5.js


var v5 = v35('v5', 0x50, esm_browser_sha1);
/* harmony default export */ var esm_browser_v5 = (v5);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/nil.js
/* harmony default export */ var nil = ('00000000-0000-0000-0000-000000000000');
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/version.js


function version_version(uuid) {
  if (!esm_browser_validate(uuid)) {
    throw TypeError('Invalid UUID');
  }

  return parseInt(uuid.substr(14, 1), 16);
}

/* harmony default export */ var esm_browser_version = (version_version);
// CONCATENATED MODULE: ../shared/node_modules/uuid/dist/esm-browser/index.js










/***/ })

/******/ });