function addScript( src, callback ) {
  var s = document.createElement( 'script' );
  s.setAttribute( 'src', src );
  s.setAttribute( 'id', 'paged-script-tag' );
  s.onload = callback;

  document.head.appendChild(s);
}

var button = document.getElementById('summary-print-button');

window.PagedConfig = {
  before: () => {},
  after: (flow) => {
    window.print();
    location.reload();
  },
};

if(button) {
  button.onclick = function() {
    addScript(chrome.extension.getURL('') + '/metapdf/paged.js', function() {});
  };
}
